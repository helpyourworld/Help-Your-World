<div id="cHeading">
	<h2><?php echo $title; ?></h2>
</div>